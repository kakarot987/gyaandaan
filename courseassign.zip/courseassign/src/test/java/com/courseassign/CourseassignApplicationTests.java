package com.courseassign;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CourseassignApplicationTests {

	@Test
	void contextLoads() {
	}

}
