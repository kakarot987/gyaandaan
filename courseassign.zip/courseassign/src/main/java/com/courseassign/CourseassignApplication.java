package com.courseassign;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CourseassignApplication {

	public static void main(String[] args) {
		SpringApplication.run(CourseassignApplication.class, args);
	}

}
